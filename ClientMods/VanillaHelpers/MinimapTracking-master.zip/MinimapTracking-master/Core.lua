-- This file is part of MinimapTracking.
--
-- MinimapTracking is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
--
-- MinimapTracking is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License along with MinimapTracking. If not, see <https://www.gnu.org/licenses/>.

if not VANILLAHELPERS_VERSION then
    DEFAULT_CHAT_FRAME:AddMessage("Minimap Tracking: VanillaHelpers is not installed.")
    return
end

MinimapTracking = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceDebug-2.0", "AceModuleCore-2.0", "AceConsole-2.0",
    "AceDB-2.0", "AceHook-2.1")
MinimapTracking:RegisterDB("MinimapTrackingDB")
MinimapTracking:RegisterDefaults("char", {
    auctioneer = true,
    banker = true,
    brainwashing = true,
    flight_master = true,
    friend = true,
    guild = true,
    innkeeper = true,
    mailbox = true,
    raid = true,
    repair = false,
    summoning = true,
    target = true,
    trainer = false,
    vendor = false,
    guidState = {},
})

function MinimapTracking:OnEnable()
    for guid, state in pairs(self.db.char.guidState) do
        state.applied = nil
    end
    self:MaintenanceTick()

    if self.db.char.auctioneer then
        SetObjectTypeBlip("Auctioneer", "Interface\\AddOns\\MinimapTracking\\Textures\\Auctioneer.blp", 1.2)
    end
    if self.db.char.banker then
        SetObjectTypeBlip("Banker", "Interface\\AddOns\\MinimapTracking\\Textures\\Banker.blp", 1.2)
    end
    if self.db.char.brainwashing then
        SetObjectTypeBlip("Brainwashing", "Interface\\AddOns\\MinimapTracking\\Textures\\Gear.blp", 1.2)
    end
    if self.db.char.flight_master then
        SetObjectTypeBlip("Flight Master", "Interface\\AddOns\\MinimapTracking\\Textures\\FlightMaster.blp", 1.2)
    end
    if self.db.char.friend then
        self:EnableFriendBlips()
    end
    if self.db.char.guild then
        self:EnableGuildBlips()
    end
    if self.db.char.innkeeper then
        SetObjectTypeBlip("Innkeeper", "Interface\\AddOns\\MinimapTracking\\Textures\\Innkeeper.blp", 1.2)
    end
    if self.db.char.mailbox then
        SetObjectTypeBlip("Mailbox", "Interface\\AddOns\\MinimapTracking\\Textures\\Mailbox.blp", 1.2)
    end
    if self.db.char.raid then
        self:EnableRaidBlips()
    end
    if self.db.char.repair then
        SetObjectTypeBlip("Repair", "Interface\\AddOns\\MinimapTracking\\Textures\\Repair.blp", 1.2)
    end
    if self.db.char.summoning then
        SetObjectTypeBlip("Summoning Ritual Object", "Interface\\AddOns\\MinimapTracking\\Textures\\Summoning.blp", 1.2)
        SetObjectTypeBlip("Summoning Ritual Unit", "Interface\\AddOns\\MinimapTracking\\Textures\\Summoning.blp", 1.2)
    end
    if self.db.char.target then
        self:EnableTargetBlips()
    end
    if self.db.char.trainer then
        SetObjectTypeBlip("Trainer", "Interface\\AddOns\\MinimapTracking\\Textures\\Trainer.blp", 1.2)
    end
    if self.db.char.vendor then
        SetObjectTypeBlip("Vendor", "Interface\\AddOns\\MinimapTracking\\Textures\\Vendor.blp", 1.2)
    end
end

MinimapTrackingOptions = AceLibrary("AceAddon-2.0"):new("AceDB-2.0", "FuBarPlugin-2.0")
MinimapTrackingOptions.name = "FuBar - Minimap Tracking"
MinimapTrackingOptions.hasIcon = "Interface\\AddOns\\MinimapTracking\\Textures\\MagnifyingGlass.blp"
MinimapTrackingOptions.defaultMinimapPosition = 140
MinimapTrackingOptions.independentProfile = true
MinimapTrackingOptions.hideWithoutStandby = false
MinimapTrackingOptions.cannotDetachTooltip = true

MinimapTrackingOptions.OnMenuRequest = {
    type = "group",
    handler = MinimapTracking,
    args = {
        auctioneer = {
            type = "toggle",
            name = "Auctioneer",
            desc = "Show auctioneers on minimap.",
            order = 1,
            get = function()
                return MinimapTracking.db.char.auctioneer
            end,
            set = function(v)
                MinimapTracking.db.char.auctioneer = v

                if v then
                    SetObjectTypeBlip("Auctioneer", "Interface\\AddOns\\MinimapTracking\\Textures\\Auctioneer.blp", 1.2)
                else
                    SetObjectTypeBlip("Auctioneer")
                end
            end,
        },
        banker = {
            type = "toggle",
            name = "Banker",
            desc = "Show bankers on minimap.",
            order = 2,
            get = function()
                return MinimapTracking.db.char.banker
            end,
            set = function(v)
                MinimapTracking.db.char.banker = v

                if v then
                    SetObjectTypeBlip("Banker", "Interface\\AddOns\\MinimapTracking\\Textures\\Banker.blp", 1.2)
                else
                    SetObjectTypeBlip("Banker")
                end
            end,
        },
        brainwashing = {
            type = "toggle",
            name = "Brainwashing Device",
            desc = "Show brainwashing devices on minimap.",
            order = 3,
            get = function()
                return MinimapTracking.db.char.brainwashing
            end,
            set = function(v)
                MinimapTracking.db.char.brainwashing = v

                if v then
                    SetObjectTypeBlip("Brainwashing", "Interface\\AddOns\\MinimapTracking\\Textures\\Gear.blp", 1.2)
                else
                    SetObjectTypeBlip("Brainwashing")
                end
            end,
        },
        flight_master = {
            type = "toggle",
            name = "Flight Master",
            desc = "Show flight masters on minimap.",
            order = 4,
            get = function()
                return MinimapTracking.db.char.flight_master
            end,
            set = function(v)
                MinimapTracking.db.char.flight_master = v

                if v then
                    SetObjectTypeBlip("Flight Master", "Interface\\AddOns\\MinimapTracking\\Textures\\FlightMaster.blp", 1.2)
                else
                    SetObjectTypeBlip("Flight Master")
                end
            end,
        },
        friend = {
            type = "toggle",
            name = "Friend",
            desc = "Show friends on minimap.",
            order = 5,
            get = function()
                return MinimapTracking.db.char.friend
            end,
            set = function(v)
                MinimapTracking.db.char.friend = v

                if v then
                    MinimapTracking:EnableFriendBlips()
                else
                    MinimapTracking:DisableFriendBlips()
                end
            end,
        },
        guild = {
            type = "toggle",
            name = "Guild",
            desc = "Show guild members on minimap.",
            order = 6,
            get = function()
                return MinimapTracking.db.char.guild
            end,
            set = function(v)
                MinimapTracking.db.char.guild = v

                if v then
                    MinimapTracking:EnableGuildBlips()
                else
                    MinimapTracking:DisableGuildBlips()
                end
            end,
        },
        innkeeper = {
            type = "toggle",
            name = "Innkeeper",
            desc = "Show innkeepers on minimap.",
            order = 7,
            get = function()
                return MinimapTracking.db.char.innkeeper
            end,
            set = function(v)
                MinimapTracking.db.char.innkeeper = v

                if v then
                    SetObjectTypeBlip("Innkeeper", "Interface\\AddOns\\MinimapTracking\\Textures\\Innkeeper.blp", 1.2)
                else
                    SetObjectTypeBlip("Innkeeper")
                end
            end,
        },
        mailbox = {
            type = "toggle",
            name = "Mailbox",
            desc = "Show mailboxes on minimap.",
            order = 8,
            get = function()
                return MinimapTracking.db.char.mailbox
            end,
            set = function(v)
                MinimapTracking.db.char.mailbox = v

                if v then
                    SetObjectTypeBlip("Mailbox", "Interface\\AddOns\\MinimapTracking\\Textures\\Mailbox.blp", 1.2)
                else
                    SetObjectTypeBlip("Mailbox")
                end
            end,
        },
        raid = {
            type = "toggle",
            name = "Raid",
            desc = "Show raid members on minimap.",
            order = 9,
            get = function()
                return MinimapTracking.db.char.raid
            end,
            set = function(v)
                MinimapTracking.db.char.raid = v

                if v then
                    MinimapTracking:EnableRaidBlips()
                else
                    MinimapTracking:DisableRaidBlips()
                end
            end,
        },
        repair = {
            type = "toggle",
            name = "Repair",
            desc = "Show repair vendors on minimap.",
            order = 10,
            get = function()
                return MinimapTracking.db.char.repair
            end,
            set = function(v)
                MinimapTracking.db.char.repair = v

                if v then
                    SetObjectTypeBlip("Repair", "Interface\\AddOns\\MinimapTracking\\Textures\\Repair.blp", 1.2)
                else
                    SetObjectTypeBlip("Repair")
                end
            end,
        },
        summoning = {
            type = "toggle",
            name = "Summoning",
            desc = "Show summoning stones on minimap.",
            order = 11,
            get = function()
                return MinimapTracking.db.char.summoning
            end,
            set = function(v)
                MinimapTracking.db.char.summoning = v

                if v then
                    SetObjectTypeBlip("Summoning Ritual Object", "Interface\\AddOns\\MinimapTracking\\Textures\\Summoning.blp", 1.2)
                    SetObjectTypeBlip("Summoning Ritual Unit", "Interface\\AddOns\\MinimapTracking\\Textures\\Summoning.blp", 1.2)
                else
                    SetObjectTypeBlip("Summoning Ritual Object")
                    SetObjectTypeBlip("Summoning Ritual Unit")
                end
            end,
        },
        target = {
            type = "toggle",
            name = "Target",
            desc = "Show targets on minimap.",
            order = 12,
            get = function()
                return MinimapTracking.db.char.target
            end,
            set = function(v)
                MinimapTracking.db.char.target = v

                if v then
                    MinimapTracking:EnableTargetBlips()
                else
                    MinimapTracking:DisableTargetBlips()
                end
            end,
        },
        trainer = {
            type = "toggle",
            name = "Trainer",
            desc = "Show trainers on minimap.",
            order = 13,
            get = function()
                return MinimapTracking.db.char.trainer
            end,
            set = function(v)
                MinimapTracking.db.char.trainer = v

                if v then
                    SetObjectTypeBlip("Trainer", "Interface\\AddOns\\MinimapTracking\\Textures\\Trainer.blp", 1.2)
                else
                    SetObjectTypeBlip("Trainer")
                end
            end,
        },
        vendor = {
            type = "toggle",
            name = "Vendor",
            desc = "Show vendors on minimap.",
            order = 14,
            get = function()
                return MinimapTracking.db.char.vendor
            end,
            set = function(v)
                MinimapTracking.db.char.vendor = v

                if v then
                    SetObjectTypeBlip("Vendor", "Interface\\AddOns\\MinimapTracking\\Textures\\Vendor.blp", 1.2)
                else
                    SetObjectTypeBlip("Vendor")
                end
            end,
        },
    },
}

