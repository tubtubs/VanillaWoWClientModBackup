-- This file is part of MinimapTracking.
--
-- MinimapTracking is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
--
-- MinimapTracking is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License along with MinimapTracking. If not, see <https://www.gnu.org/licenses/>.

local MT = MinimapTracking
if not MT then return end

MT.friendNames = {}
MT.guildNames = {}
MT.currentTargetGUID = nil
MT._events = { target = false, raid = false, friend = false, guild = false, model = false }

local CATEGORY_ORDER = { "target", "friend", "guild", "raid" }
local CATEGORY_TEX = {
    target = { "Interface\\AddOns\\MinimapTracking\\Textures\\Target.blp", 2 },
    friend = { "Interface\\AddOns\\MinimapTracking\\Textures\\Friend.blp", 2 },
    guild  = { "Interface\\AddOns\\MinimapTracking\\Textures\\Guild.blp", 2 },
    raid   = { "Interface\\AddOns\\MinimapTracking\\Textures\\Raid.blp", 2 },
}
local MAINTENANCE_INTERVAL = 60

-- Helpers


local function IsValidName(name)
    return name and name ~= "" and name ~= "Unknown"
end

local function HasAnyFlag(s)
    return s.target or s.raid or s.friend or s.guild
end

function MT:EnsureState(guid)
    local s = self.db.char.guidState[guid]
    if not s then
        s = { target = false, raid = false, friend = false, guild = false, name = nil, applied = nil }
        self.db.char.guidState[guid] = s
    end
    return s
end

function MT:UpdateNameForGUID(guid)
    local name = UnitName(guid)
    if IsValidName(name) then
        local s  = self:EnsureState(guid)
        s.name   = name
        s.friend = self.friendNames[s.name] and true or false
        s.guild  = self.guildNames[s.name] and true or false
        return true
    end
    return false
end

function MT:ApplyBlipForGUID(guid)
    local s = self.db.char.guidState[guid]
    if not s then return end

    -- Determine desired category by preference order + user profile toggles
    local desired
    for i = 1, table.getn(CATEGORY_ORDER) do
        local cat = CATEGORY_ORDER[i]
        if s[cat] and self.db.char[cat] then
            desired = cat
            break
        end
    end

    if not desired then
        if s.applied then
            SetUnitBlip(guid)
            s.applied = nil
        end
        return
    end

    if s.applied == desired then
        return
    end

    if not UnitExists(guid) or not UnitCanAssist("player", guid) then
        return
    end

    local tex, scale = CATEGORY_TEX[desired][1], CATEGORY_TEX[desired][2]
    SetUnitBlip(guid, tex, scale)
    s.applied = desired
end

function MT:MaintenanceTick()
    local toRemove = {}

    for guid, s in pairs(self.db.char.guidState) do
        local exists = UnitExists(guid)

        if exists and not s.name then
            self:UpdateNameForGUID(guid)
        end

        if not HasAnyFlag(s) and not exists then
            tinsert(toRemove, guid)
        end

        self:ApplyBlipForGUID(guid)
    end

    for _, guid in ipairs(toRemove) do
        self.db.char.guidState[guid] = nil
    end
end

function MT:RefreshMaintenance()
    local need = self._events.target or self._events.raid or self._events.friend or self._events.guild
    if need and not self._maintenance then
        self._maintenance = true
        self:ScheduleRepeatingEvent("MinimapTracking_Maintenance", function() MT:MaintenanceTick() end,
            MAINTENANCE_INTERVAL)
    elseif not need and self._maintenance then
        self._maintenance = false
        self:CancelScheduledEvent("MinimapTracking_Maintenance")
    end
end

-- Target

function MT:UpdateTargetBlip()
    local _, guid = UnitExists("target")

    if self.currentTargetGUID and (not guid or guid ~= self.currentTargetGUID) then
        local old = self:EnsureState(self.currentTargetGUID)
        old.target = false
        self:ApplyBlipForGUID(self.currentTargetGUID)
        self.currentTargetGUID = nil
    end

    if guid then
        self.currentTargetGUID = guid
        local s = self:EnsureState(guid)
        s.target = true
        self:UpdateNameForGUID(guid)
        self:ApplyBlipForGUID(guid)
    end
end

function MT:EnableTargetBlips()
    if self._events.target then return end
    self:RegisterEvent("PLAYER_TARGET_CHANGED", "UpdateTargetBlip")
    self:UpdateTargetBlip()
    self:RefreshMaintenance()
    self._events.target = true
end

function MT:DisableTargetBlips()
    if not self._events.target then return end
    self:UnregisterEvent("PLAYER_TARGET_CHANGED")
    if self.currentTargetGUID then
        local s = self:EnsureState(self.currentTargetGUID)
        s.target = false
        self:ApplyBlipForGUID(self.currentTargetGUID)
        self.currentTargetGUID = nil
    end
    self:RefreshMaintenance()
    self._events.target = false
end

-- Raid

function MT:ScanGroup()
    local numRaid = GetNumRaidMembers() or 0
    if numRaid <= 0 then
        for guid, s in pairs(self.db.char.guidState) do
            if s.raid then
                s.raid = false
                self:ApplyBlipForGUID(guid)
            end
        end
        return
    end

    local partyGUID = {}
    for i = 1, (GetNumPartyMembers() or 0) do
        local unit = "party" .. i
        local _, guid = UnitExists(unit)
        if guid then partyGUID[guid] = true end
    end

    local seen = {}
    for i = 1, numRaid do
        local unit = "raid" .. i
        local _, guid = UnitExists(unit)
        if guid and not partyGUID[guid] and not UnitIsUnit("player", guid) then
            local s = self:EnsureState(guid)
            s.raid = true
            self:UpdateNameForGUID(guid)
            self:ApplyBlipForGUID(guid)
            seen[guid] = true
        end
    end

    for guid, s in pairs(self.db.char.guidState) do
        if s.raid and not seen[guid] then
            s.raid = false
            self:ApplyBlipForGUID(guid)
        end
    end
end

function MT:EnableRaidBlips()
    if self._events.raid then return end
    self:RegisterEvent("RAID_ROSTER_UPDATE", "ScanGroup")
    self:RegisterEvent("PARTY_MEMBERS_CHANGED", "ScanGroup")
    self:ScanGroup()
    self:RefreshMaintenance()
    self._events.raid = true
end

function MT:DisableRaidBlips()
    if not self._events.raid then return end
    self:UnregisterEvent("RAID_ROSTER_UPDATE")
    self:UnregisterEvent("PARTY_MEMBERS_CHANGED")
    for guid, s in pairs(self.db.char.guidState) do
        if s.raid then
            s.raid = false
            self:ApplyBlipForGUID(guid)
        end
    end
    self:RefreshMaintenance()
    self._events.raid = false
end

-- Friends / Guild

function MT:RefreshFriendNames()
    wipe(self.friendNames)
    for i = 1, GetNumFriends() or 0 do
        local name = GetFriendInfo(i)
        if name then self.friendNames[name] = true end
    end
end

function MT:RefreshGuildNames()
    wipe(self.guildNames)
    if IsInGuild() then
        for i = 1, GetNumGuildMembers(true) or 0 do
            local name = GetGuildRosterInfo(i)
            if name then self.guildNames[name] = true end
        end
    end
end

function MT:ReevaluateAll(kind)
    local set = (kind == "friend") and self.friendNames or self.guildNames
    for guid, s in pairs(self.db.char.guidState) do
        if s.name then
            local inSet = set[s.name] and true or false
            s[kind] = inSet
            self:ApplyBlipForGUID(guid)
        end
    end
end

function MT:OnUnitModelChanged()
    local guid = arg1
    if not guid then return end
    if not UnitIsPlayer(guid) or UnitIsUnit("player", guid) or not UnitCanAssist("player", guid) then return end

    self:EnsureState(guid)
    self:UpdateNameForGUID(guid)
    self:ApplyBlipForGUID(guid)
end

function MT:OnFriendListUpdate()
    self:RefreshFriendNames()
    self:ReevaluateAll("friend")
end

function MT:OnGuildRosterUpdate()
    self:RefreshGuildNames()
    self:ReevaluateAll("guild")
end

function MT:RefreshModelWatcher()
    local need = self._events.friend or self._events.guild
    if need and not self._events.model then
        self:RegisterEvent("UNIT_MODEL_CHANGED", "OnUnitModelChanged")
        self._events.model = true
    elseif not need and self._events.model then
        self:UnregisterEvent("UNIT_MODEL_CHANGED")
        self._events.model = false
    end
end

function MT:EnableFriendBlips()
    if self._events.friend then return end
    self:RegisterEvent("FRIENDLIST_UPDATE", "OnFriendListUpdate")
    ShowFriends()
    self:RefreshFriendNames()
    self:ReevaluateAll("friend")
    self._events.friend = true
    self:RefreshModelWatcher()
    self:RefreshMaintenance()
end

function MT:DisableFriendBlips()
    if not self._events.friend then return end
    self:UnregisterEvent("FRIENDLIST_UPDATE")
    for guid, s in pairs(self.db.char.guidState) do
        if s.friend then
            s.friend = false
            self:ApplyBlipForGUID(guid)
        end
    end
    self._events.friend = false
    self:RefreshModelWatcher()
    self:RefreshMaintenance()
end

function MT:EnableGuildBlips()
    if self._events.guild then return end
    self:RegisterEvent("GUILD_ROSTER_UPDATE", "OnGuildRosterUpdate")
    GuildRoster()
    self:RefreshGuildNames()
    self:ReevaluateAll("guild")
    self._events.guild = true
    self:RefreshModelWatcher()
    self:RefreshMaintenance()
end

function MT:DisableGuildBlips()
    if not self._events.guild then return end
    self:UnregisterEvent("GUILD_ROSTER_UPDATE")
    for guid, s in pairs(self.db.char.guidState) do
        if s.guild then
            s.guild = false
            self:ApplyBlipForGUID(guid)
        end
    end
    self._events.guild = false
    self:RefreshModelWatcher()
    self:RefreshMaintenance()
end
