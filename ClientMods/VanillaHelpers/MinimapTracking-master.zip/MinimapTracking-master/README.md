# Minimap Tracking

A World of Warcraft 1.12 addon that enhances minimap functionality with customizable tracking for various unit types and objects.

<img width="398" height="421" alt="Image" src="https://github.com/user-attachments/assets/66ae341e-bde0-4406-9e1a-e4ba85b42037" />

## Features

- Track auctioneers, bankers, flight masters, innkeepers, and other NPC types
- Display party members, raid members, friends, and guild members on the minimap
- Show mailboxes, goblin brainwashing devices and other interactive objects

## Requirements

- [VanillaHelpers](https://github.com/isfir/VanillaHelpers)

